package com;

import com.Operations.DAO.Title;

import java.io.IOException;

public class Servlet extends javax.servlet.http.HttpServlet {
    @Override
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {

    }

    @Override
    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
               doPost(request,response);
        int number= Integer.parseInt(request.getParameter("number"));
          Title title =new Title(number);
        String[] titleNumber= title.GetTitles();
        int[] titleAnswer=title.GetAnswer();
//        if (request.getSession().getAttribute("title") == null) {
            request.getSession().setAttribute("title",titleNumber);
            request.getSession().setAttribute("answer",titleAnswer);
            request.getSession().setAttribute("number",number);
//        }
            request.getRequestDispatcher("/title.jsp").forward(request,response);

    }
}

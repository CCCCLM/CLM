package com;

import com.Operations.Number.user;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "Servlet2")
public class Servlet2 extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                 doGet(request,response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
               user u=new user();
               u.setUsername( request.getParameter("username"));
               u.setPassword(request.getParameter("password"));
               request.getSession().setAttribute("user",u);
               request.getRequestDispatcher("/index.jsp").forward(request,response);

    }
}

package com;

import com.Operations.Number.NB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "Servlet3")
public class Servlet3 extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
        int time = Integer.parseInt(request.getParameter("id"));
        int number= (int) request.getSession().getAttribute("number");
        request.getSession().setAttribute("time", time);
          int [] answers=new int[number];
       int[] answer= (int[]) request.getSession().getAttribute("answer");
        int fengshu =100/number;
        int fenshu1=0;
        int j=0;
        for(int i=0;i<number;i++){
            answers[i]= Integer.parseInt(request.getParameter("answer"+i));
            if(answer[i]==answers[i]){
                fenshu1=fenshu1+fengshu;
                j++;
            }
        }
        request.getSession().setAttribute("fenshu",fenshu1);
        request.getSession().setAttribute("number1",j);
        request.getSession().setAttribute("answers",answers);

        request.getRequestDispatcher("/answer.jsp").forward(request, response);

        //     }
    }
}
